#cd ../bin

#pwd



appletviewer  -J-Djava.security.policy="java.policy" DE405Propagator.html


echo press enter

read input

