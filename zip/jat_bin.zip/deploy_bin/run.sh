
cd ../bin

java  jat.examplesNOSA.IntegratorExample.SimpleIntegrator

echo press enter

read input


