cd ../bin

pwd


java -cp "../lib/*:" jat.examplesNOSA.IntegratorExample.SimpleIntegrator


echo press enter

read input

