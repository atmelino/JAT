
java -cp ../dist/jatexamples.jar:../dist/jatcore.jar:../dist/jatcoreNOSA.jar jat.examples.JulianDate.JulianDate

echo press enter

read input


