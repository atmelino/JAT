
java -cp ../dist/jatcore.jar:../dist/jatexamplesNOSA.jar:../lib/plot.jar  jat.examplesNOSA.IntegratorExample.SimpleIntegrator

echo press enter

read input


